#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <cstring>
#include <chrono>
#include "dll.hpp"


using namespace std;
using namespace std::chrono;


int main(int argc, char* argv[])
{
    doublyLL li;
	int patientNum;
	int prev;
    string line;
    ifstream myFile;
    myFile.open(argv[1]);
    if(!myFile.is_open())
    {
        cout << "File doesn't exist " << endl;
        return 0;
    }
	cout<<"Adding nodes to List:"<<endl;

	while(getline(myFile, line, ','))
    {
        patientNum = stoi(line);
		li.insert(NULL, patientNum);
    }

	li.displayNodes();
	cout<<endl;
    // record the time it takes to search an item in the dll and display the time
	for(int i = 0; i < 1000; i++)
	{
		auto start = high_resolution_clock::now();
        Node* patient = li.searchItem(24860);
        auto stop = high_resolution_clock::now();
        cout << patient->key << endl;
        auto duration = duration_cast<microseconds>(stop - start) / 100.00;
        cout << "average search time per 100 = " << duration.count() << " microseconds." << endl;
	}

    return 0;
}
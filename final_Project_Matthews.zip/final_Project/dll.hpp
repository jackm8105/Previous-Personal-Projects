#ifndef DLL_HPP
#define DLL_HPP

#include <string>

struct Node
{
    int key;
    Node* next;
    Node* prev;
};

class doublyLL
{
public:
    //creates a dll with a head = NULL
    doublyLL()
    {
    	head = NULL;
    }

    //function to insert values into the dll
    void insert(Node* prev, int key);

    //function to search the dll for a value
    Node* searchItem(int newKey);

    //function to display the entirety of the dll
    void displayNodes();
private:

    Node* head;
};


#endif
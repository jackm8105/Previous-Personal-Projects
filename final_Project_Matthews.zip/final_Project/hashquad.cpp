#include <iostream>
#include <string>
#include "hashquad.hpp"

using namespace std;


struct Node
{
    int key;
    struct Node* next;
};


HashTable::HashTable(int bsize)
{
    this->tableSize = bsize;
    table = new int[tableSize];
    for(int i=0; i<bsize; i++)
    {
        table[i] = 0;
    }
}

unsigned int HashTable::hashFunction(int key)
{
    return (key % tableSize); //finds hash value of key
}

bool HashTable::insert(int key)
{
    if(!search(key) || search(key) == key) //find hashValue for key
    {
        int hv = hashFunction(key) % tableSize;
        int index;
        for(int i = 0; i < tableSize; i++)
        {
            index = ((hv + i*i) % tableSize); //use quadratic probing to insert key
            if(table[index] != 0) //rehash
            {
                numOfcolision++;
            }
            else if(table[index] == 0) //hash value is empty
            {
                table[index] = key;
                return true;
            }
        }
        cout << "table is full." << endl;
        return false;
    }
    else
    {
        cout << "key already exists in table." << endl;
        return false;
    }   
}


void HashTable::printTable()
{
    for (int i = 0; i < tableSize; i++)
    {
        cout << i <<"|| "; //prints hashTab;e
        cout << table[i] << endl;
    }
    return;
}


int HashTable::getNumOfCollision() //needs reworking. rn i'm using the insert and search functions for all the work
{
    return numOfcolision;
}


/*uses same quadratic probing method as insert. 
the difference is that the search function returns
the found value*/
int HashTable::search(int key)
{
    int index;
    int hv = hashFunction(key) % tableSize;
    for(int i = 0; i < tableSize; i++)
    {
        index = ((hv + i*i) % tableSize);
        if(table[index] != key)
        {
            searchCollisions++;
        }
        else if(table[index] == key)
        {
            return table[index];
        }
    }
    return 0;
}
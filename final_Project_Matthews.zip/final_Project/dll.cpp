#include <iostream>
#include <string>
#include "dll.hpp"

using namespace std;


void doublyLL::insert(Node* prev, int newKey)
{
  if(head == NULL) //dll is empty
  {
    head = new Node;
    head->key = newKey;
    head->next = NULL;
    head->prev = NULL;
  }
  else if(prev == NULL) //dll has only 1 value
  {
    Node* newNode = new Node;
    newNode->key = newKey;
    newNode->next = head;
    head->prev = newNode;
    head = newNode;
  }
  else //dll has more than one value/node
  {
      Node* newNode = new Node;
      newNode->key = newKey;
      newNode->next = prev->next;
      prev->next = newNode;
      newNode->prev = prev;
  }
}


//search each node in dll till value matches the value being searched for
Node* doublyLL::searchItem(int key)
{
    Node* ptr = head;
    while (ptr != NULL && ptr->key != key)
    {
        ptr = ptr->next;
    }
    return ptr;
}


void doublyLL::displayNodes()
{
  Node* temp = head; //use a temp node to traverse dll

  while(temp->next != NULL) //traverse dll and display values of nodes along the way
  {
    cout<< temp->key <<" -> ";
    temp = temp->next;
  }

  cout<<temp->key<<endl;
}
#include "hashquad.hpp"
#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <cstring>
#include <cmath>
#include <chrono>


using namespace std;
using namespace std::chrono;

/*Main function reads the values from the provided csv file,
creates our hashTable, then inserts the values into our hashTable.
Once the hashTable is full, and/or there are no more values to insert
the function will search the hashTable for a specified value
and record the time it takes to complete the process*/

int main(int argc, char* argv[])
{
    HashTable* table = new HashTable(40009); //create hashTable bSize = 40009
    int patientNum;
    string line;
    ifstream myFile;
    myFile.open(argv[1]);
    if(!myFile.is_open())
    {
        cout << "File doesn't exist " << endl;
        return 0;
    }


    /* Figure out how to correctly record the time of each insertion, 
    and for every 100 insertions, store the average insertion time to 
    be recorded in an excel file and graphed*/
    while(getline(myFile, line, ','))
    {
        patientNum = stoi(line); // read all of the numbers from the csv file and store them as ints
        table->insert(patientNum);
        //TODO
    }


    table->printTable(); //print hashTable

    /*Searches function for a value, and records the time it 
    takes to complete each search, and then averages the 
    searchtime*/
    for(int i = 0; i < 100; i++)
    {
        int newPatient;
        auto start = high_resolution_clock::now();
        for(int j = 0; j < 100; j++)
        {
            newPatient = table->search(42692);
        }
        auto stop = high_resolution_clock::now();
        cout << "patient ID: " << newPatient << endl;
        auto duration = duration_cast<microseconds>(stop - start) / 100.00;
        cout << "Avg speed of search per 100: " << duration.count() << " microseconds" << endl;
    }
    return 0;
}

/* figure out how to record the number of collisions in both the insertion and 
search functions and store the number of collisions to be graphed in an excel graph */
//TODO
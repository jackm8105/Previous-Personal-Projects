#include <iostream>
#include "bubbleSort.hpp"


using namespace std;

// insert the key into the first empty spot
bool BubbleSort::insert(int key)
{
    for(int i = 0; i < 10000; i++)
    {
        if(testData[i] == NULL)
        {
            testData[i] = key;
            return true;
        }
    }
    cout << "array is full" << endl;
    return false;
}

//search all the data in the array until you find the key
int BubbleSort::search(int key)
{
    for(int i = 0; i < 10000; i++)
    {
        if(testData[i] == key)
        {
            return testData[i];
        } 
    }
    cout << "value doesn't exist" << endl;
    return 0;
}

//prints out the entirety of the array
void BubbleSort::display(int arr[], int size)
{
    for (int i = 0; i < size; i++)
    {
        cout << arr[i] << " ";
    }
    cout << endl;
}

//sorts the array by comparing the ints in the array to the in before them 
void BubbleSort::bubbleSort(int arr[], int n)
{
    for(int i = 0; i < n-1; i++)
    {
        for(int j = 0; j < n-i-1; j++)
        {
            if(arr[j] > arr[j+1])
            {
                swap(&arr[j], &arr[j+1]);
            }
        }
    }
}
#include <iostream> 


using namespace std;


class BubbleSort
{
    public:
        bool insert(int key);

        int search(int key);

        void display(int arr[], int size);

        void bubbleSort(int arr[], int n);

        void swap(int *a, int *b)
        {
            int temp = *a;
            *a = *b;
            *b = temp;
        }
    private:
        int testData[10000];
        float sort[100];
};